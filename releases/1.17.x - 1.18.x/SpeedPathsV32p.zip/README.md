# SpeedPathsV3-Data-Pack
 
This Data Pack give players and some entities a speed boost if they stand on certain blocks

Two versions available in the releases folder.

###Blocks:
Smooth Stone, Smooth Sandstone and Smooth Quartz
Grass Path works for other entities, but the second version will also give players speed.

###Entities:
Mostly rideables entities. Horses, Mules, Donkeys, Skeleton Horses, Llamas, Trader Llamas, Pigs with saddle.

###More info:
This video explains all the behavior: https://youtu.be/wxqVpSWZdzE

